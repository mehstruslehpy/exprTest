valgrind ../main <<-ENDOFMESSAGE
p
#Proposition 1
u
v
P
q #continue

#Conclusion
b
o
u
v
P
u
v
P
c # continue
ENDOFMESSAGE
