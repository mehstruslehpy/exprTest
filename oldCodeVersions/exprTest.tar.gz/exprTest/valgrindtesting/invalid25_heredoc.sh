valgrind ../main <<-ENDOFMESSAGE
	p #proof 

	u
	n
	b
	a
	u
	v
	P
	u
	v
	Q
	q

	#Conclusion
	b
	a
	u
	n
	u
	v
	P
	u
	n
	u
	v
	Q
	c #continue to proof
	ENDOFMESSAGE
