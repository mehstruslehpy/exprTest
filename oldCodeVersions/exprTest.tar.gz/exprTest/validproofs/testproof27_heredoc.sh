../main <<-ENDOFMESSAGE
p
#Proposition 1
u
v
P
q #continue

#Conclusion
b
a
u
v
P
u
v
P
c # continue
ENDOFMESSAGE
