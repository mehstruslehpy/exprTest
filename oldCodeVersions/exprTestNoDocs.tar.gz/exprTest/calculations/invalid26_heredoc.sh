valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	b
	c
	u
	v
	P
	u
	v
	Q
	q

	#Conclusion
	b
	o
	u
	v
	P
	u
	v
	Q
	q #continue to proof
	1
	ENDOFMESSAGE
