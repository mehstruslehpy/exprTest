../main <<-ENDOFMESSAGE
	p #proof 

	b
	c
	u
	n
	u
	v
	P
	u
	n
	u
	v
	Q
	q

	#Conclusion
	b
	c
	u
	v
	P
	u
	v
	Q
	c #continue to proof
	ENDOFMESSAGE
