valgrind ../main <<-ENDOFMESSAGE
	c 
	
	b
	c
	u
	v
	A
	u
	v
	B
	c

	b
	o
	u
	v
	C
	u
	v
	B
	c

	b
	o
	u
	v
	C
	u
	v
	A
	q 
	1
	1
	0
	ENDOFMESSAGE
