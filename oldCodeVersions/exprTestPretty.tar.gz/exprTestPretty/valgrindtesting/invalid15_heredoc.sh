valgrind ../main <<-ENDOFMESSAGE
	p #proof 
	
	b
	c
	u
	v
	A
	u
	v
	B
	c

	b
	c
	u
	v
	C
	u
	v
	D
	c

	b
	c
	u
	v
	F
	b
	a
	u
	v
	C
	u
	v
	D
	q

	#Conclusion
	b
	c
	u
	v
	E
	u
	v
	C
	c #continue to proof
	ENDOFMESSAGE
