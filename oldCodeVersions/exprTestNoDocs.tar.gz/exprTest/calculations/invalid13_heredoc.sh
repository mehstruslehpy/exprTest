valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	u
	n
	b
	a
	u
	v
	A
	u
	v
	B
	c

	b
	o
	u
	n
	u
	v
	A
	u
	v
	C
	c

	#Conclusion
	u
	n
	b
	a
	u
	v
	C
	u
	v
	B
	q #continue to proof
	1
	0
	1
	ENDOFMESSAGE
