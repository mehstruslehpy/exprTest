../main <<-ENDOFMESSAGE
	p #proof 

	b
	c
	u
	v
	A
	u
	v
	B
	c

	b
	c
	u
	v
	C
	u
	v
	B
	q
	
	#Conclusion
	b
	c
	u
	v
	A
	u
	v
	C
	c #continue to proof
	ENDOFMESSAGE
