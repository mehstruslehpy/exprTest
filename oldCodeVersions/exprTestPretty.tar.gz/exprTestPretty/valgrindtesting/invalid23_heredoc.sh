valgrind ../main <<-ENDOFMESSAGE
	p #proof 

	b
	c
	b
	a
	u
	v
	A
	u
	v
	B
	u
	n
	b
	a
	u
	v
	C
	u
	v
	D
	c

	u
	v
	C
	c

	b
	c
	u
	v
	E
	u
	v
	B
	q

	#Conclusion
	u
	n
	u
	v
	E
	c #continue to proof
	ENDOFMESSAGE
