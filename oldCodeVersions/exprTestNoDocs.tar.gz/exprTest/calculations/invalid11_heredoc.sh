valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	b
	c
	b
	a
	u
	v
	A
	u
	v
	B
	u
	v
	C
	c

	#Conclusion
	b
	c
	u
	v
	B
	u
	v
	C
	q #continue to proof
	1
	1
	ENDOFMESSAGE
