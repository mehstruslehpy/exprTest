valgrind ../main <<-ENDOFMESSAGE
	p #proof 

	b
	c
	u
	v
	A
	b
	c
	u
	v
	B
	u
	v
	C
	c

	b
	o
	u
	v
	B
	u
	n
	b
	c
	u
	v
	C
	u
	v
	D
	q

	#Conclusion
	b
	c
	u
	v
	D
	u
	n
	b
	o
	u
	v
	A
	u
	v
	B
	c #continue to proof
	ENDOFMESSAGE
