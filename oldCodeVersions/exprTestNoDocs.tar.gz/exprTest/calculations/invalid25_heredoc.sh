valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	u
	n
	b
	a
	u
	v
	P
	u
	v
	Q
	c

	#Conclusion
	b
	a
	u
	n
	u
	v
	P
	u
	n
	u
	v
	Q
	q #continue to proof
	0
	0
	1
	1
	ENDOFMESSAGE
