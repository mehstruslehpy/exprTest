../main <<-ENDOFMESSAGE
p
#Proposition 1
b
o
u
v
P
u
v
Q
c #continue

b
c
u
v
P
u
v
R
c

b
c
u
v
Q
u
v
R
q

#Conclusion
u
v
R
c # continue
ENDOFMESSAGE
