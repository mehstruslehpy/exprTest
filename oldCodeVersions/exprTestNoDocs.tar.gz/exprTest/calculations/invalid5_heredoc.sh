valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	b
	o
	u
	v
	A
	u
	v
	B
	c
	
	#Conclusion
	u
	v
	A
	q #continue to calc
	0
	1
	ENDOFMESSAGE
