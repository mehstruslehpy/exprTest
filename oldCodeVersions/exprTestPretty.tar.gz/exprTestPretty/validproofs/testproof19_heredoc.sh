../main <<-ENDOFMESSAGE
	p

	#Proposition 1
	b
	c
	u
	v
	A
	u
	v
	B
	c #continue
	
	#Proposition 2
	u
	n
	u
	v
	B
	q #continue

	#Conclusion
	b
	a
	b
	c
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	B
	u
	v
	A
	c # continue
	ENDOFMESSAGE
