valgrind ../main <<-ENDOFMESSAGE
	c #proof 
	
	u
	n
	b
	a
	u
	v
	A
	u
	v
	B
	c

	#Conclusion
	u
	n
	b
	a
	b
	c
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	B
	u
	v
	A
	q #continue to proof
	0
	0
	0
	0
	ENDOFMESSAGE
