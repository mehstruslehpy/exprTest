valgrind ../main <<-ENDOFMESSAGE
p

#Proposition 1
b
c
u
n
u
v
P
b
c
u
v
Q
u
v
R
c #continue

#Proposition 2
u
n
u
v
P
c #continue

u
v
Q
q

#Conclusion
u
v
R
c # continue
ENDOFMESSAGE
