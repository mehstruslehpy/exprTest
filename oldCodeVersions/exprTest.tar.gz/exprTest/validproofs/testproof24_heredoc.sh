../main <<-ENDOFMESSAGE
p
#Proposition 1
b
a
u
v
Q
u
v
P
q #continue

#Conclusion
b
a
u
v
P
u
v
Q
c # continue
ENDOFMESSAGE
