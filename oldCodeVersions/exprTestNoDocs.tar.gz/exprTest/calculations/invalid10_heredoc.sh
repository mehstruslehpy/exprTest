valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	b
	a
	b
	c
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	B
	u
	v
	A
	c

	b
	c
	u
	v
	C
	u
	v
	B
	c

	u
	n
	b
	a
	u
	v
	C
	u
	v
	D
	c
	
	u
	v
	D
	c

	#Conclusion
	u
	n
	u
	v
	A
	q #continue to proof

	1
	1
	0
	0

	ENDOFMESSAGE
