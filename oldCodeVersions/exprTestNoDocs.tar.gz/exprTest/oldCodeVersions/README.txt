these are just old versions of the current code the main changes are 
one is an early working version with no mem leaks the other is a slightly
cleaned up version of the same thing

This current version is preferred because it uses smart pointers
