valgrind ../main <<-ENDOFMESSAGE
	p #proof 
	
	b
	c
	u
	v
	A
	u
	n
	u
	v
	B
	q

	#Conclusion
	u
	n
	b
	c
	u
	v
	A
	u
	v
	B
	c #continue to proof
	ENDOFMESSAGE
