valgrind ../main <<-ENDOFMESSAGE
	c #proof 
	
	b
	c
	b
	c
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	C
	u
	v
	D
	c

	b
	c
	u
	v
	B
	u
	v
	D
	c

	b
	c
	u
	v
	A
	u
	v
	C
	c
	
	#Conclusion
	b
	c
	u
	v
	A
	u
	v
	D
	q #continue to proof
	1
	1
	1
	ENDOFMESSAGE
