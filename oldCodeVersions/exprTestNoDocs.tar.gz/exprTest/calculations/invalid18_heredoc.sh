valgrind ../main <<-ENDOFMESSAGE
	c #proof 
	
	b
	c
	u
	v
	A
	u
	n
	u
	v
	B
	c

	#Conclusion
	u
	n
	b
	c
	u
	v
	A
	u
	v
	B
	q #continue to proof
	1
	1
	ENDOFMESSAGE
