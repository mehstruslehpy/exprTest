valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	b
	c
	b
	a
	u
	v
	A
	u
	v
	B
	u
	n
	b
	a
	u
	v
	C
	u
	v
	D
	c

	u
	v
	C
	c

	b
	c
	u
	v
	E
	u
	v
	B
	c

	#Conclusion
	u
	n
	u
	v
	E
	q #continue to proof
	1
	1
	0
	0
	ENDOFMESSAGE
