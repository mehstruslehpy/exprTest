valgrind ../main <<-ENDOFMESSAGE
	p #proof 

	u
	n
	b
	a
	u
	n
	u
	v
	A
	u
	n
	u
	v
	B
	c

	u
	n
	u
	v
	C
	c

	b
	o
	u
	v
	D
	u
	n
	u
	v
	A
	c

	b
	c
	b
	a
	u
	v
	C
	u
	n
	u
	v
	E
	u
	n
	u
	v
	B
	c

	u
	n
	u
	v
	D
	q

	#Conclusion
	u
	n
	u
	v
	E
	c #continue to proof
	ENDOFMESSAGE
