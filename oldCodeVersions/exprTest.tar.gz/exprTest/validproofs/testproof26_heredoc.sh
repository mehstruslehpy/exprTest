../main <<-ENDOFMESSAGE
p
#Proposition 1
b
c
b
a
u
v
P
u
v
Q
b
a
u
v
R
u
v
S
c #continue

u
n
u
n
u
v
P
c

u
v
Q
q

#Conclusion
u
v
S
c # continue
ENDOFMESSAGE
