../main <<-ENDOFMESSAGE
	#Proposition 1
	b
	c
	b
	c
	u
	v
	A
	u
	v
	B
	u
	v
	C
	c #continue
	
	#Proposition 2
	b
	c
	u
	v
	C
	b
	a
	u
	v
	D
	u
	v
	E
	q #continue

	#Conclusion
	b
	c
	u
	v
	B
	u
	v
	D
	c # continue
	ENDOFMESSAGE
