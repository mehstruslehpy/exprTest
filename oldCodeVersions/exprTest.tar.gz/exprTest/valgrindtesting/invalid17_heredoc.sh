valgrind ../main <<-ENDOFMESSAGE
	p #proof 
	
	u
	n
	b
	a
	u
	v
	A
	u
	v
	B
	q

	#Conclusion
	b
	a
	u
	n
	u
	v
	A
	u
	n
	u
	v
	B
	c #continue to proof
	ENDOFMESSAGE
