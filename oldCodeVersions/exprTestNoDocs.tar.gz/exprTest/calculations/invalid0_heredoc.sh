valgrind ../main <<-ENDOFMESSAGE
	c

	#Proposition 1
	b
	c
	u
	v
	A
	u
	v
	B
	c #continue to next proposition
	
	#Proposition 2
	u
	v
	B
	c

	#Proposition 3
	u
	v
	A
	q
	1
	0
ENDOFMESSAGE
