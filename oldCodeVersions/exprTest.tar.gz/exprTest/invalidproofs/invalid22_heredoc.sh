../main <<-ENDOFMESSAGE
	p #proof 
	
	b
	o
	u
	n
	u
	v
	A
	u
	n
	u
	v
	B
	q

	#Conclusion
	u
	n
	b
	o
	u
	v
	A
	u
	v
	B
	c #continue to proof
	ENDOFMESSAGE
