valgrind ../main <<-ENDOFMESSAGE
p
#Proposition 1
b
c
u
n
u
v
P
u
n
u
n
u
v
Q
c #continue

u
n
u
n
u
n
u
v
P
q
#Conclusion
u
v
Q
c # continue
ENDOFMESSAGE
