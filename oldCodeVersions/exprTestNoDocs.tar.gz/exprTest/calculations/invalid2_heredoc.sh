valgrind ../main <<-ENDOFMESSAGE
	c 
	
	u
	v
	T
	c #continue to next proposition
	
	b
	c
	u
	v
	T
	b
	o
	u
	v
	B
	u
	v
	M
	c

	b
	c
	u
	v
	M
	u
	v
	H
	c

	u
	v
	B
	q
	1
	0
	0
	1
	ENDOFMESSAGE
