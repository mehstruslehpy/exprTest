../main <<-ENDOFMESSAGE
	#Proposition 1
	b
	c
	u
	n
	b
	o
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	C
	u
	v
	D
	c #continue
	
	#Proposition 2
	b
	a
	u
	n
	u
	v
	A
	u
	n
	u
	v
	D
	q #continue

	#Conclusion
	b
	c
	u
	n
	u
	v
	B
	u
	n
	u
	v
	C
	c # continue
	ENDOFMESSAGE
