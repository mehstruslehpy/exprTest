#include "andexp.h"
AndExp::AndExp ( BoolExp* op1, BoolExp* op2)
    : BoolExp(AND_EXP)
{
    _operand1 = op1;
    _operand2 = op2;
}
AndExp::~AndExp ( )
{
    if(_operand1)
    {
        delete _operand1;
        _operand1 = nullptr;
    }
    if(_operand2)
    {
        delete _operand2;
        _operand2 = nullptr;
    }
}
bool AndExp::Evaluate(Context& con)
{
    bool val1 = _operand1->Evaluate(con);
    bool val2 = _operand2->Evaluate(con);
    return val1 && val2;
}
BoolExp* AndExp::Replace(const char* name, BoolExp& exp)
{
    return new AndExp(_operand1->Replace(name,exp),
                      _operand2->Replace(name,exp));
}
BoolExp* AndExp::Copy() const
{
    return new AndExp(_operand1->Copy(),
                      _operand2->Copy());
}
string AndExp::Name() const
{
    string ret = "(" + _operand1->Name() + " & " + _operand2->Name() + ")";
    return ret;
}
BoolReturn AndExp::Infer()
{
    return BoolReturn(_operand1,_operand2);
}
