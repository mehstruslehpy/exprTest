valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	u
	n
	b
	a
	u
	v
	A
	u
	v
	X
	c

	u
	n
	b
	o
	u
	v
	A
	u
	v
	X
	q #continue to proof
	1
	ENDOFMESSAGE
