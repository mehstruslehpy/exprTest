valgrind ../main <<-ENDOFMESSAGE
	c #proof 
	
	b
	c
	u
	v
	A
	u
	v
	B
	c
	
	b
	c
	u
	v
	B
	u
	v
	A
	q #continue to proof
	0
	0
	ENDOFMESSAGE
