../main <<-ENDOFMESSAGE
	p #proof 

	b
	c
	u
	v
	P
	u
	v
	Q
	q

	u
	n
	b
	o
	u
	v
	P
	u
	v
	Q
	c #continue to proof
	ENDOFMESSAGE
