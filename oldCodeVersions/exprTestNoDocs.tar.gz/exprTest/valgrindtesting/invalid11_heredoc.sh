valgrind ../main <<-ENDOFMESSAGE
	p #proof 

	b
	c
	b
	a
	u
	v
	A
	u
	v
	B
	u
	v
	C
	q

	#Conclusion
	b
	c
	u
	v
	B
	u
	v
	C
	c #continue to proof
	ENDOFMESSAGE
