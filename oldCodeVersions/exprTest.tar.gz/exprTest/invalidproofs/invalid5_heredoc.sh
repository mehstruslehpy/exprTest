../main <<-ENDOFMESSAGE
	p #proof 

	b
	o
	u
	v
	A
	u
	v
	B
	q
	
	#Conclusion
	u
	v
	A
	c #continue to proof
	ENDOFMESSAGE
