../main <<-ENDOFMESSAGE
	p

	#Proposition 1
	b
	c
	b
	o
	u
	v
	A
	u
	v
	B
	u
	v
	C
	q #continue
	
	
	#Conclusion
	b
	c
	u
	n
	u
	v
	C
	u
	n
	u
	v
	B
	c # continue
	ENDOFMESSAGE
