valgrind ../main <<-ENDOFMESSAGE
	p #proof 
	
	u
	n
	b
	a
	u
	v
	A
	u
	v
	B
	q

	#Conclusion
	u
	n
	b
	a
	b
	c
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	B
	u
	v
	A
	c #continue to proof
	ENDOFMESSAGE
