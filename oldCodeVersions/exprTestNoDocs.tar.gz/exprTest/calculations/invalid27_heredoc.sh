valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	b
	c
	u
	n
	u
	v
	P
	u
	n
	u
	v
	Q
	c

	#Conclusion
	b
	c
	u
	v
	P
	u
	v
	Q
	q #continue to proof
	1
	1
	0
	ENDOFMESSAGE
