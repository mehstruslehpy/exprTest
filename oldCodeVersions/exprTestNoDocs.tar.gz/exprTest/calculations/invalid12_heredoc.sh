valgrind ../main <<-ENDOFMESSAGE
	c #proof 
	
	b
	c
	b
	a
	u
	v
	A
	u
	v
	B
	u
	v
	C
	c
	
	b
	c
	b
	o
	u
	v
	C
	u
	v
	D
	u
	n
	u
	v
	E
	c

	#Conclusion
	u
	n
	b
	a
	u
	v
	A
	u
	v
	E
	q #continue to proof
	1
	0
	1
	ENDOFMESSAGE
