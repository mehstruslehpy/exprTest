../main <<-ENDOFMESSAGE
	p
	#Proposition 1
	b
	a
	b
	c
	u
	n
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	B
	u
	n
	u
	v
	A
	q #continue

	#Conclusion
	u
	n
	b
	a
	b
	c
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	B
	u
	v
	A
	c # continue
	ENDOFMESSAGE
