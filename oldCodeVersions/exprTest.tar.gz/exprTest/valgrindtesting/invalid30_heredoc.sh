valgrind ../main <<-ENDOFMESSAGE
	p #proof 

	u
	n
	b
	a
	u
	v
	A
	u
	v
	X
	q

	u
	n
	b
	o
	u
	v
	A
	u
	v
	X
	c #continue to proof
	ENDOFMESSAGE
