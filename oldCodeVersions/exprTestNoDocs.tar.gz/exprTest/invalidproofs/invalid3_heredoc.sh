../main <<-ENDOFMESSAGE
	p 
	
	b
	c
	u
	v
	A
	u
	v
	B
	c

	b
	o
	u
	v
	C
	u
	v
	B
	q

	#Conclusion
	b
	o
	u
	v
	C
	u
	v
	A
	c #continue to proof
	ENDOFMESSAGE
