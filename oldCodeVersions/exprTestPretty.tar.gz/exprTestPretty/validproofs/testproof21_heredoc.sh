../main <<-ENDOFMESSAGE
p

#Proposition 1
u
v
P
c #continue
#Proposition 2
b
c
u
v
Q
u
v
R
c #continue

b
c
u
v
P
u
v
Q
q

#Conclusion
u
v
R
c # continue
ENDOFMESSAGE
