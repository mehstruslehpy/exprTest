valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	#a single proposition argument needs a garbage variable
	u
	v
	B
	c

	u
	n
	b
	c
	u
	v
	Q
	b
	a
	u
	v
	P
	u
	n
	u
	v
	P
	q #continue to proof
	1
	0
	1
	ENDOFMESSAGE
