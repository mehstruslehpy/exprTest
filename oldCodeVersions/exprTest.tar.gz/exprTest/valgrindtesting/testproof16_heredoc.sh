valgrind ../main <<-ENDOFMESSAGE
	p

	#Proposition 1
	b
	c
	u
	v
	A
	u
	v
	B
	c #continue
	
	#Proposition 2
	b
	c
	u
	v
	B
	u
	v
	C
	q #continue
	
	#Conclusion
	b
	c
	u
	v
	A
	u
	v
	C
	c # continue
	ENDOFMESSAGE
