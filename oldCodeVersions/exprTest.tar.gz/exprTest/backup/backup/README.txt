TODO: 
	-Flesh out the inference rules skeleton code in prover.cpp
	-Clean out unused fields in prover.h
	-Write a fun ui in main.cpp
		-Two modes: Calculation for computing binary formulas
					Proof for creating proofs of various formulas
