#ifndef _DEFS_H_
#define _DEFS_H_
#include "boolexp.h"
#include "context.h"
#include "varexp.h"
#include "notexp.h"
#include "andexp.h"
#include "orexp.h"
#include "condexp.h"
#include "prover.h"
#endif
