valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	u
	n
	b
	a
	u
	v
	A
	u
	n
	u
	v
	B
	c
	
	#Conclusion
	u
	n
	b
	a
	u
	v
	B
	u
	n
	u
	v
	A
	q
	1
	1
	ENDOFMESSAGE
