../main <<-ENDOFMESSAGE
p
#Proposition 1
b
c
u
v
P
b
a
u
v
Q
u
v
R
c #continue

u
v
P
q

#Conclusion
b
a
u
v
P
u
v
Q
c # continue
ENDOFMESSAGE
