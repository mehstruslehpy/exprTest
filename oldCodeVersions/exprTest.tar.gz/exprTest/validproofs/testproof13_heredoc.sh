../main <<-ENDOFMESSAGE
	p

	#Proposition 1
	b
	c
	u
	v
	A
	u
	v
	B
	c #continue
	
	#Proposition 2
	b
	c
	u
	n
	u
	v
	A
	u
	v
	B
	q #continue
	
	
	#Conclusion
	u
	v
	B
	c # continue
	ENDOFMESSAGE
