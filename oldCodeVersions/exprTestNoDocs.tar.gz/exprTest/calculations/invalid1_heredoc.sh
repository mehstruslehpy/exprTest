valgrind ../main <<-ENDOFMESSAGE
	c 
	
	#Proposition 1
	b
	c
	u
	v
	R
	u
	v
	P
	c 
	
	#Proposition 2
	u
	n
	u
	v
	R
	c 
	
	#Proposition 3
	u
	n
	u
	v
	P
	q
	0
	1
	ENDOFMESSAGE
