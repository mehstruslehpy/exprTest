valgrind ../main <<-ENDOFMESSAGE
	p #proof 

	u
	n
	b
	a
	u
	v
	A
	u
	v
	B
	c

	b
	o
	u
	n
	u
	v
	A
	u
	v
	C
	q

	#Conclusion
	u
	n
	b
	a
	u
	v
	C
	u
	v
	B
	c #continue to proof
	ENDOFMESSAGE
