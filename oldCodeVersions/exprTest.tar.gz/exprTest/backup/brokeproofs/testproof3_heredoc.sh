../main <<-ENDOFMESSAGE
	#Proposition 1
	b
	c
	u
	v
	A
	u
	v
	B
	c #continue
	
	#Proposition 2
	b
	o
	u
	v
	A
	b
	a
	u
	v
	A
	u
	v
	C
	q #continue

	#Conclusion
	b
	a
	u
	v
	A
	u
	v
	C
	c # continue
	ENDOFMESSAGE
