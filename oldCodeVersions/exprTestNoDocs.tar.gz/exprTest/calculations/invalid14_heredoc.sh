valgrind ../main <<-ENDOFMESSAGE
	c #proof 

	u
	n
	b
	a
	u
	n
	u
	v
	A
	u
	n
	u
	v
	B
	c

	u
	n
	u
	v
	C
	c

	b
	o
	u
	v
	D
	u
	n
	u
	v
	A
	c

	b
	c
	b
	a
	u
	v
	C
	u
	n
	u
	v
	E
	u
	n
	u
	v
	B
	c

	u
	n
	u
	v
	D
	c

	#Conclusion
	u
	n
	u
	v
	E
	q #continue to proof
	1
	0
	1
	0
	ENDOFMESSAGE
