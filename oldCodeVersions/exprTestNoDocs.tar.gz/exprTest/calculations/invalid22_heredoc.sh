valgrind ../main <<-ENDOFMESSAGE
	c #proof 
	
	b
	o
	u
	n
	u
	v
	A
	u
	n
	u
	v
	B
	c

	#Conclusion
	u
	n
	b
	o
	u
	v
	A
	u
	v
	B
	q #continue to proof
	0
	1
	0
	1
	ENDOFMESSAGE
