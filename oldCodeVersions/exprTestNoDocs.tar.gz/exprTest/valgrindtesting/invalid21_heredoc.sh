valgrind ../main <<-ENDOFMESSAGE
	p #proof 
	
	b
	c
	u
	v
	A
	b
	a
	u
	v
	B
	u
	v
	C
	c

	b
	c
	b
	c
	u
	v
	D
	u
	v
	E
	u
	v
	A
	q

	#Conclusion
	b
	o
	u
	v
	E
	u
	v
	C
	c #continue to proof
	ENDOFMESSAGE
