valgrind ../main <<-ENDOFMESSAGE
	p

	#Proposition 1
	b
	o
	u
	v
	A
	u
	v
	B
	c #continue
	
	#Proposition 2
	b
	c
	u
	v
	A
	u
	v
	C
	c #continue
	
	#Proposition 3
	b
	c
	u
	v
	B
	u
	v
	D
	q #quit
	
	#Conclusion
	b
	o
	u
	v
	C
	u
	v
	D
	c # continue
	ENDOFMESSAGE
