../main <<-ENDOFMESSAGE
	p #proof 

	u
	n
	b
	a
	u
	v
	A
	u
	n
	u
	v
	B
	q
	
	#Conclusion
	u
	n
	b
	a
	u
	v
	B
	u
	n
	u
	v
	A
	c #continue to proof
	ENDOFMESSAGE
