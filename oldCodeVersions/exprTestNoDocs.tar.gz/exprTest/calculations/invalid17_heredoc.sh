valgrind ../main <<-ENDOFMESSAGE
	c #proof 
	
	u
	n
	b
	a
	u
	v
	A
	u
	v
	B
	c

	#Conclusion
	b
	a
	u
	n
	u
	v
	A
	u
	n
	u
	v
	B
	q #continue to proof
	0
	1
	ENDOFMESSAGE
