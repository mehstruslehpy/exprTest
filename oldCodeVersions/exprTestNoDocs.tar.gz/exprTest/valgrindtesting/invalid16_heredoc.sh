valgrind ../main <<-ENDOFMESSAGE
	p #proof 
	
	b
	c
	u
	v
	A
	b
	a
	u
	v
	F
	u
	v
	P
	c

	b
	c
	u
	n
	u
	v
	A
	u
	v
	N
	q

	#Conclusion
	u
	v
	P
	c #continue to proof
	ENDOFMESSAGE
