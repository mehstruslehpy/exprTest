../main <<-ENDOFMESSAGE
	p #proof 

	b
	a
	b
	c
	u
	v
	A
	u
	v
	B
	b
	c
	u
	v
	B
	u
	v
	A
	c

	b
	c
	u
	v
	C
	u
	v
	B
	c

	u
	n
	b
	a
	u
	v
	C
	u
	v
	D
	c
	
	u
	v
	D
	q

	#Conclusion
	u
	n
	u
	v
	A
	c #continue to proof
	ENDOFMESSAGE
